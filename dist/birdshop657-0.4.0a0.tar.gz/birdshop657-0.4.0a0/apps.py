from django.apps import AppConfig


class BirdShop657Config(AppConfig):
    name = 'birdshop657'
    default_auto_field = 'django.db.models.BigAutoField'
